"""
Conditional Logic
"""

if 100 > 10:
    print("Hundred is greater than 10")

value = 'red'

if value == 'green':
    print("Go")
elif value == 'yellow':
    print("Prepare to stop")
else:
    print("Stop")

print("It will always print")
