"""
== --> Value Equality
!= --> Not equal to
< --> Less than
> --> Greater than
<= --> Less than or equal to
>= --> Greater than or equal to
"""

bool_one = 10 == 11
not_equal = 10 != 11
less_than = 10 < 11
greater_than = 10 > 9
lt_eq = 10 <= 10
gt_eq = 10 >= 11 - 1
print (gt_eq)