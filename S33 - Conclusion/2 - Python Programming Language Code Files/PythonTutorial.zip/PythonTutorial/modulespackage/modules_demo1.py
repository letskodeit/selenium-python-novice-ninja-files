"""
https://docs.python.org/3/library/
"""
import math
from math import sqrt

class ModulesDemo():

    def builtin_modules(self):
        print(math.sqrt(100))
        print(sqrt(100))


m = ModulesDemo()
m.builtin_modules()