class ModulesDemo():

    def external_modules(self):
        dump("Dump this value")


m = ModulesDemo()
m.external_modules()