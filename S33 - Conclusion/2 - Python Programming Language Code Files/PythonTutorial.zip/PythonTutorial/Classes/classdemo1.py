"""
Object Oriented Programming
"""

s = "this is a string"
a = "one more string"
s.upper()
s.lower()

print(type('s'))
print(type('a'))
print(type([1, 2, 3]))