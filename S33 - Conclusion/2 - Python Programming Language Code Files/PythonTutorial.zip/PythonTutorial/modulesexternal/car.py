"""
This is our own module which does not exist in python builtins
"""

def info(make, model):
    print("Make of the car: " + make)
    print("Model of the car: " + model)