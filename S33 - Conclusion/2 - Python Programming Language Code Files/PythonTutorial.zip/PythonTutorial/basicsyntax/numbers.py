int_num = 10
float_num = 20.0

print(int_num)
print(float_num)

a = 10
b = 20

print("*******************")

add = a + b
print(add)

sub = b - a
print(sub)

multi = a * b
print(multi)

div_mychoice = b / a
print(div_mychoice)