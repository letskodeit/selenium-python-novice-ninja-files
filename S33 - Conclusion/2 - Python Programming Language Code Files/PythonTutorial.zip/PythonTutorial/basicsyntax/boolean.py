"""
Examples to show how boolean works in python
"""

a = True
b = False

print(a)
print(b)

print("**************************")
print(bool(0))
print(bool(1))
print(bool(2))
print("**************************")

c = ""
print(bool(c))

c = "Some Value"
print(bool(c))