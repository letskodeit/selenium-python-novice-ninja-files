# This is a one line comment

# Exponentiation
# 10 * 10 ... 20
exponents = 10 ** 2
print(exponents)


"""
This is a multi-line comment
Modulo - It returns the remainder
"""

remainder = 11 % 3
print(remainder)