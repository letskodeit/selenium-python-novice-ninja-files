"""
variables rules
"""

import keyword
print(keyword.kwlist)


a = b = c = 10
print(a)
print(b)
print(c)

x, y, z = 10, 20, 30
print(x)
print(y)
print(z)